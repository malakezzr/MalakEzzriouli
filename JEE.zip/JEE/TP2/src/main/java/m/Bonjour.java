package m;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Bonjour extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Afficher "Bonjour"
        out.println("<html><body>");
        out.println("<p>Bonjour</p>");

        // Afficher la date courante
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String dateCourante = sdf.format(new Date());
        out.println("<p>Date courante : " + dateCourante + "</p>");

        // Générer le tableau HTML avec 9 lignes et 3 colonnes
        out.println("<table border='1'>");
        for (int i = 0; i < 9; i++) {
            out.println("<tr>");
            for (int j = 0; j < 3; j++) {
                out.println("<td>Ligne " + (i + 1) + ", Colonne " + (j + 1) + "</td>");
            }
            out.println("</tr>");
        }
        out.println("</table>");

        // Afficher le tableau avec les noms et moyennes
        String[] noms = {"Étudiant1", "Étudiant2", "Étudiant3", "Étudiant4", "Étudiant5"};
        double[] moyennes = {15.5, 18.0, 12.8, 16.2, 14.7};

        out.println("<p>Étudiants et Moyennes :</p>");
        out.println("<table border='1'>");
        out.println("<tr><th>Nom</th><th>Moyenne</th></tr>");
        for (int i = 0; i < noms.length; i++) {
            out.println("<tr><td>" + noms[i] + "</td><td>" + moyennes[i] + "</td></tr>");
        }
        out.println("</table>");

        out.println("</body></html>");
    }
}
