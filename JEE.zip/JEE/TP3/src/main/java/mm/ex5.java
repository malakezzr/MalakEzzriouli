package mm;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ex5 extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<Etudiant> listeEtudiants = GestionEtudiants.getListeEtudiants();
       
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><body>");
        out.println("<h2>Liste des Etudiants</h2>");

        // Affichage des étudiants avec couleurs en fonction de la moyenne
        out.println("<table border='1'>");
        out.println("<tr><th>CIN</th><th>Nom</th><th>Moyenne</th></tr>");
        
        for (int i = 1; i <= listeEtudiants.size(); i++) {
            Etudiant etudiant = listeEtudiants.get(i - 1);
            
            // Déterminez la couleur en fonction de la moyenne
            String couleurFond = (etudiant.getMoyenne() < 10) ? "red" : "yellow";
            
            // Ajoutez une ligne avec une couleur de fond
            out.println("<tr style='background-color:" + couleurFond + "'>");
            out.println("<td>" + etudiant.getCin() + "</td>");
            out.println("<td>" + etudiant.getNom() + "</td>");
            out.println("<td>" + etudiant.getMoyenne() + "</td>");
            out.println("</tr>");
        }
        
        out.println("</table>");
        out.println("</body></html>");
    }
}
