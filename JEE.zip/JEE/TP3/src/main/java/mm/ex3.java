package mm;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ex3 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    //http://localhost:8080/TP3/ex3
    
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Récupération de la liste des étudiants
        List<Etudiant> listeEtudiants = GestionEtudiants.getListeEtudiants();

        // Paramètres de la réponse HTTP
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Génération de la page Web dynamique
        out.println("<html><body>");
        out.println("<h2>Liste des Etudiants</h2>");

        // Affichage des étudiants sous forme de tableau
        out.println("<table border='1'>");
        out.println("<tr><th>CIN</th><th>Nom</th><th>Moyenne</th></tr>");
        for (int i = 1; i <= listeEtudiants.size(); i++) {
            Etudiant etudiant = listeEtudiants.get(i - 1);
            out.println("<tr>");
            out.println("<td>" + etudiant.getNom() + "</td>");
            out.println("<td>" + etudiant.getCin() + "</td>");
            out.println("<td>" + etudiant.getMoyenne() + "</td>");
            out.println("</tr>");
        }
        out.println("</table>");

        out.println("</body></html>");
    }
}
