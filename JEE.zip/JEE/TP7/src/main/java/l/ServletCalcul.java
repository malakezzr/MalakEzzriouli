package l;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletCalcul
 */
@WebServlet("/ServletCalcul")
public class ServletCalcul extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletCalcul() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Récupération des opérandes et de l'opération
            int operande1 = Integer.parseInt(request.getParameter("operande1"));
            int operande2 = Integer.parseInt(request.getParameter("operande2"));
            String operation = request.getParameter("operation");

            // Calcul du résultat
            int resultat = 0;
            switch (operation) {
                case "+":
                    resultat = operande1 + operande2;
                    break;
                case "-":
                    resultat = operande1 - operande2;
                    break;
                case "*":
                    resultat = operande1 * operande2;
                    break;
                case "/":
                    if (operande2 == 0) {
                        throw new ArithmeticException("Division par zéro");
                    }
                    resultat = operande1 / operande2;
                    break;
                default:
                    throw new IllegalArgumentException("Opération non supportée");
            }

            // Envoi du résultat à la page resultat.jsp
            request.setAttribute("resultat", resultat);
            RequestDispatcher dispatcher = request.getRequestDispatcher("resultat.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            // En cas d'erreur, envoi d'un message d'erreur à la page saisie.jsp
            request.setAttribute("message", "Erreur de calcul: " + e.getMessage());
            RequestDispatcher dispatcher = request.getRequestDispatcher("saisie.jsp");
            dispatcher.forward(request, response);
        }
    }


}
