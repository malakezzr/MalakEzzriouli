package nn;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/IdentificationServlet")
public class IdentificationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Récupération des paramètres du formulaire
        String login = request.getParameter("login");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        // Vérification des identifiants et du rôle
        if ("admin".equals(login) && "admin".equals(password)) {
            // Redirection vers la page succès en fonction du rôle
            switch (role) {
                case "IM":
                    response.sendRedirect("succesIM.html");
                    break;
                case "CM":
                    response.sendRedirect("succesCM.html");
                    break;
                case "AV":
                    response.sendRedirect("succesAV.html");
                    break;
                default:
                    response.sendRedirect("echec.html");
            }
        } else {
            // Redirection vers la page échec
            response.sendRedirect("echec.html");
        }
    }
}
