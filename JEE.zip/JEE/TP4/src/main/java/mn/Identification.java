package mn;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Identification")
public class Identification extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Récupération des paramètres du formulaire
        String login = request.getParameter("login");
        String password = request.getParameter("password");

 

        // Vérification des identifiants
        if ("admin".equals(login) && "admin".equals(password)) {
            // Redirection vers la page succès
            response.sendRedirect("succes.html");
        } else {
            // Redirection vers la page échec
            response.sendRedirect("echec.html");
        }
    }
}
