package tp2.estn;

import java.util.Scanner;

public class TestPile {
    public static void main(String[] args) {
        Pile p = new Pile();
        char c;

        System.out.println("Entrez une chaîne de caractères (terminez par '#'):");

        Scanner clavier = new Scanner(System.in);
        c = clavier.next().charAt(0);
        clavier.nextLine(); // consume the newline character

        while (c != '#') {
            p.empiler(c);
            c = clavier.next().charAt(0);
            clavier.nextLine(); // consume the newline character
        }

        while (!p.estVide()) {
            c = p.sommet();
            System.out.print(c);
            p.depiler();
        }
    }
}
