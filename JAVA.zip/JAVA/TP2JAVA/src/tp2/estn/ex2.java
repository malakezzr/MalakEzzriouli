package tp2.estn;

import java.util.Scanner;

public class ex2 {
	public static void main(String[] args)
	{
		Pile p=new Pile();
		char c;
		
		System.out.print("entrer une chaine de caractère qui se termine avec #");
		Scanner clavier=new Scanner(System.in);
		c=clavier.next().charAt(0);
		clavier.nextLine();
		
		while(c!='#') 
		{
			if(c=='(') {
				p.empiler(c);
			   /* c=clavier.next().charAt(0);
			    clavier.nextLine();*/
			}
			else if(c==')')
			{
				if(!p.estVide())
				{
				p.depiler();
				}
				else 
				{
                    System.out.println("Il y a plus de parenthèses fermantes que de parenthèses ouvrantes.");
                    return;
		        }
		   }
			c=clavier.next().charAt(0);
			clavier.nextLine();
		
	   }
		 if (p.estVide()) {
	            System.out.println("L'expression est bien parenthésée.");
	        } else {
	            System.out.println("Il y a plus de parenthèses ouvrantes que de parenthèses fermantes.");
	        }
	}

}
