package tp2.estn;

/**
 * La classe Pile représente une pile d'éléments de type caractère (char).
 * Une pile est une structure de données basée sur le principe Last In, First Out (LIFO).
 */
public class Pile {
    static final int MAX = 8;
    char t[];
    int top;

    /**
     * Constructeur de la classe Pile.
     * Initialise la pile en créant un tableau de caractères de taille MAX et en initialisant le sommet à -1.
     */
    public Pile() {
        t = new char[MAX];
        top = -1;
    }

    /**
     * Empile un caractère sur la pile.
     *
     * @param c Le caractère à empiler.
     */
    public void empiler(char c) {
        if (!estPleine()) {
            t[++top] = c;
        } else {
            System.out.println("La pile est pleine");
        }
    }

    /**
     * Retourne le caractère situé au sommet de la pile sans le retirer.
     *
     * @return Le caractère au sommet de la pile.
     */
    public char sommet() {
        if (!estVide()) {
            return t[top];
        } else {
            System.out.println("La pile est vide");
            return '\0';
        }
    }

    /**
     * Dépile un élément de la pile.
     */
    public void depiler() {
        if (!estVide()) {
            top--;
        } else {
            System.out.println("La pile est vide, impossible de dépiler.");
        }
    }

    /**
     * Vérifie si la pile est vide.
     *
     * @return true si la pile est vide, false sinon.
     */
    public boolean estVide() {
        return (top < 0);
    }

    /**
     * Vérifie si la pile est pleine.
     *
     * @return true si la pile est pleine, false sinon.
     */
    public boolean estPleine() {
        return (top == MAX - 1);
    }
}
