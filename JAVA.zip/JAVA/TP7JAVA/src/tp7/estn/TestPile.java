package tp7.estn;

public class TestPile {
    public static void main(String[] args) {
        Pile pile = new PileImpl();

        // Test de la pile
        pile.empiler('A');
        pile.empiler('B');
        pile.empiler('C');

        // Affichage du sommet de la pile
        System.out.println("Sommet de la pile : " + pile.sommet());

        // Dépiler un élément
        pile.depiler();

        // Affichage du sommet après dépilement
        System.out.println("Sommet de la pile après dépilement : " + pile.sommet());
    }
}
