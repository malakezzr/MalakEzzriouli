package tp7.estn;

class MaPile implements Pile {
    private StringBuilder s;

    public MaPile() {
        s = new StringBuilder(MAX);
    }

    public void empiler(char c) {
        s.append(c);
    }

    public char sommet() {
        if (!vide()) {
            return s.charAt(s.length() - 1);
        }
        throw new IllegalStateException("La pile est vide.");
    }

    public void depiler() {
        if (!vide()) {
            s.deleteCharAt(s.length() - 1);
        } else {
            throw new IllegalStateException("La pile est vide.");
        }
    }

    public boolean vide() {
        return s.length() == 0;
    }

    public boolean pleine() {
        return s.length() == MAX;
    }

	@Override
	public boolean estVide() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean estPleine() {
		// TODO Auto-generated method stub
		return false;
	}
}

class TestMaPile {
    public static void main(String[] args) {
        MaPile pile = new MaPile();
        // Test de la pile
        pile.empiler('a');
        pile.empiler('b');
        pile.empiler('c');

        while (!pile.vide()) {
            System.out.println(pile.sommet());
            pile.depiler();
        }
    }
}

