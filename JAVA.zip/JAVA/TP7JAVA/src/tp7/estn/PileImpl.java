package tp7.estn;

public class PileImpl implements Pile {
    private char[] t;
    private int top;

    public PileImpl() {
        t = new char[MAX];
        top = -1;
    }

    @Override
    public void empiler(char c) {
        if (!estPleine()) {
            t[++top] = c;
        } else {
            System.out.println("La pile est pleine");
        }
    }

    @Override
    public char sommet() {
        if (!estVide()) {
            return t[top];
        } else {
            System.out.println("La pile est vide");
            return '\0';
        }
    }

    @Override
    public void depiler() {
        if (!estVide()) {
            top--;
        } else {
            System.out.println("La pile est vide, impossible de dépiler.");
        }
    }

    @Override
    public boolean estVide() {
        return (top < 0);
    }

    @Override
    public boolean estPleine() {
        return (top == MAX - 1);
    }
}
