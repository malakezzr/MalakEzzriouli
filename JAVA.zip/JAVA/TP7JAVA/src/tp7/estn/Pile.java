package tp7.estn;

public interface Pile {
	 int MAX = 8;

	    void empiler(char c);

	    char sommet();

	    void depiler();

	    boolean estVide();

	    boolean estPleine();
}

   
   