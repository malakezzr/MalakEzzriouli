package tp7.estn;

class TaPile implements Pile {
    private char[] t;
    private int sommet;

    public TaPile() {
        t = new char[MAX];
        sommet = -1;
    }

    public void empiler(char c) {
        if (!pleine()) {
            t[++sommet] = c;
        } else {
            throw new IllegalStateException("La pile est pleine.");
        }
    }

    public char sommet() {
        if (!vide()) {
            return t[sommet];
        }
        throw new IllegalStateException("La pile est vide.");
    }

    public void depiler() {
        if (!vide()) {
            sommet--;
        } else {
            throw new IllegalStateException("La pile est vide.");
        }
    }

    public boolean vide() {
        return sommet == -1;
    }

    public boolean pleine() {
        return sommet == MAX - 1;
    }

	@Override
	public boolean estVide() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean estPleine() {
		// TODO Auto-generated method stub
		return false;
	}
}

class TestTaPile {
    public static void main(String[] args) {
        TaPile pile = new TaPile();
        // Test de la pile
        pile.empiler('x');
        pile.empiler('y');
        pile.empiler('z');

        while (!pile.vide()) {
            System.out.println(pile.sommet());
            pile.depiler();
        }
    }
}
