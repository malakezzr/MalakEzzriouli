package tp5.estn;

public abstract class General {
	public int x = 2; // Variable d'instance (non considérée static)

    // Méthode abstraite à implémenter par les sous-classes
    abstract public void qui();

    public void moi() {
        System.out.println("Méthode générale");
    }

}
