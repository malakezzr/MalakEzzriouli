package tp5.estn;

public class Coureur implements Loisir {
	// Implémentation de la méthode courirOuMarcher
    public void courirOuMarcher() {
        System.out.println("Je cours " + distance + " Km.");
    }

    // Ajout d'une nouvelle méthode
    public void courirMoins() {
        System.out.println("Je cours " + (distance / 2) + " Km.");
    }
    Loisir c = new Coureur(); // Possible
    

}
