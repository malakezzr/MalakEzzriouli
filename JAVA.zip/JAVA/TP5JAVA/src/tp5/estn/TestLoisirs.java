package tp5.estn;

public class TestLoisirs {
    public static void main(String[] args) {
        Loisir mesLoisirs[] = {new Marcheur(), new Coureur()};

        for (Loisir loisir : mesLoisirs) {
            loisir.courirOuMarcher();
        }
    }
}

