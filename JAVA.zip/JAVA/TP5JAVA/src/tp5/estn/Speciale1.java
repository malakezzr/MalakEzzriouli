package tp5.estn;

public class Speciale1 {
	// Implementation de qui()
    public void qui() {
        System.out.println("C'est la sous-classe Speciale1");
    }

    // Redéfinition de la méthode moi de la classe Generale
    public void moi() {
        System.out.println("Redéfinition dans Speciale1");
    }
    

}
