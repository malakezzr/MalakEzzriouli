package tp5.estn;

	interface A {
	    void f();
	    
	    int x = 42;
	    default void g() {
	        System.out.println("Méthode g() de l'interface A");
	}

	interface B {
	    void f();
	    
	    int x = 21;
	}

	class C implements A, B {
	    public void f() {
	        System.out.println("Méthode f() de la classe C");
	    }
	}
	public class TestInterfaces {
	    public static void main(String[] args) {
	        C c = new C();
	        c.f(); // Appel de la méthode f() de la classe C
	        c.g(); 
	        System.out.println(A.x); // 42
	        System.out.println(B.x); // 21
	    }

	}
	}
