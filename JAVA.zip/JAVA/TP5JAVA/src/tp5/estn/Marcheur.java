package tp5.estn;

class Marcheur implements Loisir {
    // Implémentation de la méthode courirOuMarcher
    public void courirOuMarcher() {
        System.out.println("Moi, je marche...");
    }
}
