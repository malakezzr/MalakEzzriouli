package tp5.estn;

public interface Loisir {
	int distance = 21;

    void courirOuMarcher();

}
