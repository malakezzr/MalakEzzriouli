package tp5.estn;

public class Test {
	 public static void main(String args[]) {
	        Speciale1 s = new Speciale1();
	        s.moi();
	        s.qui();
	        s.x++;
	        System.out.println(s.x);
	    }

}
