package tp3.estn;

/**
 * Classe Point du plan avec ses coordonnées x et y
 */
public class Point extends Object {
    private int x, y;

    /**
     * Méthode qui affecte la valeur de son paramètre au Point this.
     *
     * @param p La valeur à affecter à la coordonnée x.
     */
    public void setX(int p) {
        x = p;
    }

    /**
     * Méthode qui affecte la valeur de son paramètre au Point this.
     *
     * @param p La valeur à affecter à la coordonnée y.
     */
    public void setY(int p) {
        y = p;
    }

    /**
     * Méthode qui retourne la coordonnée x du point.
     *
     * @return La coordonnée x du point.
     */
    public int getX() {
        return x;
    }

    /**
     * Méthode qui retourne la coordonnée y du point.
     *
     * @return La coordonnée y du point.
     */
    public int getY() {
        return y;
    }

    /**
     * Méthode qui déplace le point d'une longueur sur l'axe des x et des y.
     *
     * @param dx La longueur du déplacement sur l'axe x.
     * @param dy La longueur du déplacement sur l'axe y.
     */
    public void deplacer(int dx, int dy) {
        x += dx;
        y += dy;
    }

    /**
     * Méthode qui ramène le point à l'origine.
     */
    public void reset() {
        x = 0;
        y = 0;
    }

    /**
     * Méthode qui calcule la distance entre le point this et un autre point b.
     *
     * @param b Le point avec lequel calculer la distance.
     * @return La distance entre les deux points.
     */
    public double distance(Point b) {
        int dx = b.getX() - this.x;
        int dy = b.getY() - this.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Méthode statique qui calcule la distance entre deux points a et b.
     *
     * @param a Le premier point.
     * @param b Le deuxième point.
     * @return La distance entre les deux points.
     */
    public static double distance(Point a, Point b) {
        int dx = b.getX() - a.getX();
        int dy = b.getY() - a.getY();
        return Math.sqrt(dx * dx + dy * dy);
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Point point = (Point) o;
        return x == point.x && y == point.y;
    }
}
