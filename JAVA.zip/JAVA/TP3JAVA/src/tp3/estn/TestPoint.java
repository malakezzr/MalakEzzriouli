package tp3.estn;

/**
 * Classe de test pour la classe Point.
 */
public class TestPoint {
    public static void main(String args[]) {
        Point p = new Point();
        p.setX(3);
        p.setY(4);

        System.out.println("Coordonnées du point p :");
        System.out.println("x = " + p.getX());
        System.out.println("y = " + p.getY());

        // Déplacement du point
        p.deplacer(2, 3);

        System.out.println("Nouvelles coordonnées du point p après déplacement :");
        System.out.println("x = " + p.getX());
        System.out.println("y = " + p.getY());

        // Ramener le point à l'origine
        p.reset();

        System.out.println("Coordonnées du point p après reset :");
        System.out.println("x = " + p.getX());
        System.out.println("y = " + p.getY());

        // Calcul de distance entre deux points
        Point q = new Point();
        q.setX(1);
        q.setY(2);

        double distance1 = p.distance(q);
        System.out.println("Distance entre les points p et q : " + distance1);

        double distance2 = Point.distance(p, q);
        System.out.println("Distance entre les points p et q (méthode statique) : " + distance2);
    }
}
