package tp3.estn;

public class TestP {
	public static void main(String args[]) {
        Point p = new Point();
        p.setX(3);
        p.setY(4);

        Point q = new Point();
        q.setX(3);
        q.setY(4);

        System.out.println("Les points p et q sont égaux : " + p.equals(q));
    }

}
