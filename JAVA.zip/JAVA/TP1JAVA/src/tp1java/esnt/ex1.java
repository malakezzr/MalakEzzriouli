package tp1java.esnt;

public class ex1 {
	public static void main (String[] args)
	{
		System.out.println("Hello Wolrd !");
		System.out.println("Bonjour, ça va?");
        System.out.println("سلام");
	}


}
