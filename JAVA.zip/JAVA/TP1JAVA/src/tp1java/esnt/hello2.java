package tp1java.esnt;

public class hello2 {
	 static public void main(String args[]) {
	        if (args.length != 0)
	            System.out.println("Bonjour " + args[0]);
	    }

}
