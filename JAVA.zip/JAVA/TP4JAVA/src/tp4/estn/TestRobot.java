package tp4.estn;

public class TestRobot {
    public static void main(String args[]) {
        // Instancier un robot avec le constructeur par défaut
        Robot robot = new Robot();
        System.out.println("État initial du robot : " + robot);

        // Avancer le robot
        robot.avancer();
        System.out.println("État du robot après avancer() : " + robot);

        // Changer la direction du robot
        robot.setDirection(2);
        System.out.println("État du robot après setDirection(2) : " + robot);

        // Instancier un robot avec le constructeur paramétré
        Robot robot2 = new Robot(3, 4, 1);
        System.out.println("État du deuxième robot : " + robot2);
    }
}
