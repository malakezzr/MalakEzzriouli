package tp4.estn;

public class TestRectangle {
    public static void main(String args[]) {
        Point hautGauche = new Point(1, 4);
        Point basDroit = new Point(5, 2);

        Rectangle rect = new Rectangle(hautGauche, basDroit);

        System.out.println("Surface du rectangle : " + rect.surface());

        rect.zoom(2, 2);

        System.out.println("Surface après zoom : " + rect.surface());

        rect.afficher();
    }
}
