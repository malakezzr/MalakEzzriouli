package tp4.estn;

public class Robot extends Point {
    private int direction; // direction actuelle

    public Robot() {
        super(0, 0);
        direction = 3; // Sud par défaut
    }

    public Robot(int x, int y, int direction) {
        super(x, y);
        setDirection(direction);
    }

    public void avancer() {
        switch (direction) {
            case 1:
                y++;
                break;
            case 2:
                x++;
                break;
            case 3:
                y--;
                break;
            case 4:
                x--;
                break;
            default:
                ;
        }
    }

    public void setDirection(int d) {
        // Vérifier que la direction est entre 1 et 4
        if (d >= 1 && d <= 4) {
            direction = d;
        } else {
            System.out.println("La direction doit être un entier compris entre 1 et 4.");
        }
    }

    // Vous pouvez supprimer le constructeur par défaut Robot()
    // car vous avez maintenant un constructeur paramétré.
    @Override
    public String toString() {
    return "Robot - Coordonnées : (" + getX() + ", " + getY() + "), Direction : " + direction;
    }
}

