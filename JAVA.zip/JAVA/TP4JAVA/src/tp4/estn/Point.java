package tp4.estn;

public class Point {
    private int x, y;

    public Point() {
        this(0, 0);
    }

    public Point(int a, int b) {
        x = a;
        y = b;
    }

    // Constructeur copie
    public Point(Point p) {
        this.x = p.x;
        this.y = p.y;
    }

    // Méthodes set et get
    public void setX(int p) {
        x = p;
    }

    public void setY(int p) {
        y = p;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    // Autres méthodes (déplacement, reset, distance, etc.)
}
