package tp4.estn;

public class Rectangle {
    private Point hg, bd; // Les coins haut à gauche

    public Rectangle() {
        // rectangle par défaut. Choisir son initialisation
        hg = new Point(0, 0);
        bd = new Point(1, 1);
    }

    public Rectangle(Point h, Point b) {
        // initialisation des coins à partir des paramètres
        hg = new Point(h);
        bd = new Point(b);
    }

    public void afficher() {
        // Affiche les coordonnées des coins
        System.out.println("Coin haut gauche : (" + hg.getX() + ", " + hg.getY() + ")");
        System.out.println("Coin bas droit : (" + bd.getX() + ", " + bd.getY() + ")");
    }

    public int surface() {
        // calcule de la surface
        return (bd.getX() - hg.getX()) * (bd.getY() - hg.getY());
    }

    public void zoom(int deltax, int deltay) {
        // Dilatation des coordonnées. Delta donné.
        bd.setX(bd.getX() + deltax);
        bd.setY(bd.getY() + deltay);
    }

    // autres méthodes...
}
