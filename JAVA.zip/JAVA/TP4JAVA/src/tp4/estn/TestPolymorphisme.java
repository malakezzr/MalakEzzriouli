package tp4.estn;

public class TestPolymorphisme {
    public static void main(String[] args) {
        // Instancier un objet Point
        Point p = new Point(6, 7);
        System.out.println("Point : " + p.toString());

        // Réaffecter p avec un objet Robot
        Robot r = new Robot(1, 2, 3);
        p = r;

        // La méthode toString() appelée dépendra du type réel de l'objet référencé par p
        System.out.println("Robot : " + p.toString());
    }
}
