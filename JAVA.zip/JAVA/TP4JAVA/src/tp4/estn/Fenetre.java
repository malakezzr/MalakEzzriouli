package tp4.estn;

public class Fenetre {
    private Rectangle fenetre;
    private String titre;

    public Fenetre(Rectangle fenetre, String titre) {
        this.fenetre = fenetre;
        this.titre = titre;
    }

    // Ajoutez des méthodes utiles pour la gestion de la fenêtre
}
